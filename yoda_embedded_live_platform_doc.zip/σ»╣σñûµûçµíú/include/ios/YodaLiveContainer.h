//
//  YodaLiveContainer.h
//  YodaSDK
//
//  Created by yuchen on 17/7/7xyu.
//  Copyright © 2017年 yiyou. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface YodaLiveContainer : NSObject

/**
 显示直播主窗口（必需登录成功后才能显示）

 @param rect 主窗口显示大小和位置
 @param origin 最小化时的位置
 @param parentView 父View，可以为nil，为nil时表示父View为最顶层Window
 */
+ (void)showInRect:(CGRect)rect miniButtonOrigin:(CGPoint)origin parentView:(UIView * _Nullable)parentView ;

/**
 关闭直播窗口
 */
+ (void)close;


@end
