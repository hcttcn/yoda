//
//  YodaSDK.h
//  YodaSDK
//
//  Created by yuchen on 17/6/19xyu.
//  Copyright © 2017年 yiyou. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "YodaLiveContainer.h"

//! Project version number for YodaSDK.
FOUNDATION_EXPORT double YodaSDKVersionNumber;

//! Project version string for YodaSDK.
FOUNDATION_EXPORT const unsigned char YodaSDKVersionString[];

typedef NS_ENUM(NSUInteger, YodaClosedReason) {
    YodaClosedReasonNormal      = 0,    // 正常关闭
    YodaClosedReasonNotLogin    = 1,    // 未登录或登录失效
    YodaClosedReasonKicked      = 2,    // 被踢下线（如顶号）
};

@protocol YodaSDKDelegate <NSObject>


/**
 Yoda窗口被关闭时执行的回调

 @param reason 0为正常关闭，非0为异常关闭
 */
- (void)yoda_onClosed:(YodaClosedReason)reason;

@end

@interface YodaSDK : NSObject

/**
 获取YodaSDK实例。单例模式，不能通过init创建

 @return YodaSDK实例
 */
+ (YodaSDK *_Nonnull)sharedInstance;

/**
 委派，用于接收sdk回调
 */
@property (nonatomic, weak) id<YodaSDKDelegate> _Nullable delegate;

- (id _Nullable)init __attribute__((unavailable("cannot use init for this class, use +(YodaSDK *) sharedInstance instead")));

/**
 设置连接生产环境 / 测试环境

 @param mode 要连接的环境， 0: 生产环境（默认值）   1: 测试环境
 
 */

- (void)setDevMode:(int)mode;

/**
 初始化Yoda

 @param appId Yoda分配的应用唯一标识符
 */
- (void)prepareWithAppId:(UInt32)appId;
- (UInt32)appId;

/**
 登录Yoda服务

 @param guid 游戏用户id
 @param openId 从gateway拿到的openId
 @param accessToken 从gateway拿到的accessToken
 @param success 登录成功的回调
 @param failed 失败的回调
 */
- (void)loginWithGuid:(NSString *_Nonnull)guid openId:(NSString *_Nonnull)openId accessToken:(NSString *_Nonnull)accessToken success:(void (^_Nullable)(void))success failed:(void (^_Nullable)(NSError * _Nonnull error))failed;


/**
 获取YodaSDK版本号

 @return 版本号
 */
- (NSString *_Nonnull)version;



/**
 设置自定义字体
 
 @param fontName 字体的名称
 */
- (void)setCustomFontName:(NSString *_Nonnull)fontName;


/**
 设置自定义字体路径
 
 @param fontPath 字体文件的绝对路径
 
 若设置了有效的自定义字体名称，则此设置不会生效
 
 */
- (void)setCustomFontPath:(NSString *_Nonnull)fontPath;

/**
 设置创建自定义字体的block
 
 若设置了有效的自定义字体名称 或 自定义字体文件路径，则此设置不会生效
 
 @param block 生成字体的block
 */
- (void)setCustomFontBlock:(UIFont*_Nullable(^_Nullable)(CGFloat fontSize))block;

@end
